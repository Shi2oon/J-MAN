function [mat] = matprop(~)

%Material properties
mat.E  = 110000; %[MPa]
mat.stressstate = 'plane_stress'; %set to'plane_strain' or 'plane_stress'

%Element type (deprec)
mat.eltype  = 'Q4';



