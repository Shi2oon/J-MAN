function [gl] = makeglobal(el, mesh)

%find non zero displacment nodes
% logic = ((sqrt(mesh.dDIC(1,:).^2+mesh.dDIC(2,:).^2))~=0);

%global U
% ux = reshape(logic.*mesh.UDIC(1,:), mesh.winDIC(2),mesh.winDIC(1));
% uy = reshape(logic.*mesh.UDIC(2,:),mesh.winDIC(2),mesh.winDIC(1));
x = reshape(mesh.UDIC(1,:), mesh.winDIC(2),mesh.winDIC(1));
y = reshape(mesh.UDIC(2,:),mesh.winDIC(2),mesh.winDIC(1));

gl.x = x(mesh.winFE(1,2):mesh.winFE(2,2),mesh.winFE(1,1):mesh.winFE(2,1));
gl.y = y(mesh.winFE(1,2):mesh.winFE(2,2),mesh.winFE(1,1):mesh.winFE(2,1));

%global d
% dx = reshape(logic.*mesh.dDIC(1,:),mesh.winDIC(2),mesh.winDIC(1));
% dy = reshape(logic.*mesh.dDIC(2,:), mesh.winDIC(2),mesh.winDIC(1));
% gl.dx = dx(mesh.winFE(1,2):mesh.winFE(2,2),mesh.winFE(1,1):mesh.winFE(2,1));
% gl.dy = dy(mesh.winFE(1,2):mesh.winFE(2,2),mesh.winFE(1,1):mesh.winFE(2,1));

%global deformed
% gl.xdef = gl.x;%+gl.dx*1;
% gl.ydef = gl.y;%+gl.dy*1;

%interpolate VM stress at nodes
gl.smises = griddata(el.gpx,el.gpy,el.gpsmises,gl.x, gl.y,'linear');
gl.smises(gl.smises>3*nanmean(gl.smises(:))) = NaN;

gl.exx = griddata(el.gpx,el.gpy,el.gpexx,gl.x, gl.y,'linear');
gl.eyy = griddata(el.gpx,el.gpy,el.gpeyy,gl.x, gl.y,'linear');
gl.exy = griddata(el.gpx,el.gpy,el.gpexy,gl.x, gl.y,'linear');

gl.sxx = griddata(el.gpx,el.gpy,el.gpsxx,gl.x, gl.y,'linear');
gl.syy = griddata(el.gpx,el.gpy,el.gpsyy,gl.x, gl.y,'linear');
gl.sxy = griddata(el.gpx,el.gpy,el.gpsxy,gl.x, gl.y,'linear');
gl.sxy(abs(gl.sxy)>3*nanmean(abs(gl.sxy(:)))) = NaN;

gl.Axx = griddata(el.gpx,el.gpy,el.gpAxx,gl.x, gl.y,'linear');
gl.Axy = griddata(el.gpx,el.gpy,el.gpAxy,gl.x, gl.y,'linear');
gl.Ayx = griddata(el.gpx,el.gpy,el.gpAyx,gl.x, gl.y,'linear');
gl.Ayy = griddata(el.gpx,el.gpy,el.gpAyy,gl.x, gl.y,'linear');

gl.W = griddata(el.gpx,el.gpy,el.gpW,gl.x, gl.y,'linear');