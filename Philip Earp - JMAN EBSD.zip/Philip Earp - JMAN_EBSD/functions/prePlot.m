function DIC = prePlot(mesh,gl,y,el)
%%
%Figure
if(y)
    DIC = figure('Position',[50 100 1000 800]);
elseif(y==0)
    DIC = figure('Position',[50 100 500 400]);
end
axesDIC = axes('Parent',DIC);
hold(axesDIC,'all');

%DIC grid
axis([min(gl.x(1,:)),max(gl.x(1,:)),min(gl.y(:,1)),max(gl.y(:,1))])
hgrid = gridxy(mesh.UDIC(1,1:mesh.winDIC(2):end), mesh.UDIC(2,1:mesh.winDIC(2)),...
    'LineStyle','-','Color',[0.5 0.5 0.5]);

%% plot strain contours
hdisp2 = pcolor(gl.x,gl.y,gl.Axy);

%%Row and Colunm numbering
text(mesh.UDIC(1,1),mesh.UDIC(2,1),'1',...
    'VerticalAlignment','top','HorizontalAlignment','left',...
    'FontSize',6,'Color',[0 0 0]);
text(mesh.UDIC(1,2:mesh.winDIC(2)),mesh.UDIC(2,2:mesh.winDIC(2)),num2str((2:mesh.winDIC(2))'),... %Row numbering
    'VerticalAlignment','top','HorizontalAlignment','left',...
    'FontSize',6,'Color',[0 0 0]);
text(mesh.UDIC(1,(mesh.winDIC(2)+1):mesh.winDIC(2):end),mesh.UDIC(2,(mesh.winDIC(2)+1):mesh.winDIC(2):end),num2str((2:mesh.winDIC(1))'),... %Column numbering
    'VerticalAlignment','middle','HorizontalAlignment','left',...
    'FontSize',6,'Color',[0 0 0]);

%% edit figure
xlabel('along specimen length (mm)');
ylabel('along specimen width (mm)');
title('DIC displacment field showing FE elements and J integral elements');

colorbar('peer',axesDIC);

% axis([min(mesh.UDIC(1,:)) max(mesh.UDIC(1,:)) min(mesh.UDIC(2,:)) max(mesh.UDIC(2,:))]);
axis equal;


