% JMAN_EBSD_Dashboard

clear all; colordef white; clc; 
close all;

input.fullpath = 'C:\Users\Phllip\OneDrive - Nexus365\Documents\3. HR-EBSD\JMAN_EBSD Development\1 - Twin in Titanium\Raw Data\twin16_XEBSD.mat';
input.StressUnits = 'MPa';
input.rotate180 = false;
input.stepsize = 0.15; % um
input.isXEBSD = true;

% cd 'C:\Users\Phllip\OneDrive - Nexus365\Documents\Software\JMAN_EBSD'

JMAN_EBSD