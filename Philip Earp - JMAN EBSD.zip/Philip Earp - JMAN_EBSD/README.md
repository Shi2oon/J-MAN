# JMAN_EBSD
Calculation of J-integral from cross-correlation EBSD (HR-EBSD) data
