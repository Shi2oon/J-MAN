%% FE code to evaluate J-integral from DIC images, by Thorsten Becker - b.thorsten@gmail.com
%% and Selim Barhli - selim.barhli@ensiacet.fr

%DIC IMAGE:         <--------------mesh.winsize(1)---------->
%                  ...........................................
%             |    :  FE----------------------------------   :                                            .
%             |    :  |  Jo----------------------------  |   :
%             |    :  |  |  Ji----------------------  |  |   :
% mesh.winsize(2)  :========> crack in pos x dir.  |  |  |   :
%             |    :  |  |  ----------------------Ji  |  |   :
%             |    :  |  ----------------------------Jo  |   :
%             |    :  ----------------------------------FE   :                                            .
%                  :.........................................:
% FE => mesh.winFE(x&y,point)-window size of image considered for the FE analysis
% Jo => Jint.nout(x&y,point) -outer Jintegral path
% Ji => Jint.nin(x&y,point)  -inner Jintegral path
%VARIABLES:
% mat.  - material and element properties
% mesh. - FE mesh
% el.   - FE elements, variables and results
% Jint. - J-integral elements, variables and results
% gl.   - Global interpolation of FE analysis from Gauss points
% %{
close all; clear all; colordef white; clc;
fprintf(1,'FE code to evaluate J-integral from displacement fields\nby Thorsten Becker - b.thorsten@gmail.com\n');
fprintf(1,'and Selim M. Barhli - selim.barhli@materials.ox.ac.uk\n');

%% INPUT MATERIAL PROPERTIES AND DATA
fprintf('\nLoading data...');
scan_number = 0;
[mat] = matprop();                %sets material peoperties: E,nu,etc...
[mesh] = loadUd(scan_number);                %loads DIC data
fprintf('done\n')
fprintf(1,'data points loaded:%6.0f \n',length(mesh.UDIC));


%% MESHING & STRAIN/STRESSES CALCULATIONS
fprintf('\nMeshing...');
[el,mesh] = meshDIC(mat,mesh);
fprintf('done\n')
fprintf(1,'Element type:%3s %10s\n', mat.eltype, mat.stressstate);
fprintf(1,'Number of elements:%6.0f\n',mesh.nFE);


%FEM (calculate element stress/strain & assemble into global system)
fprintf('\nFEM analysis');
[el] = FEanalysisStrains(el,mat,mesh);%runs isoparematric FE anlysis to slove for strain and stress at Gauss points
[gl] = makeglobal(el, mesh);         %Interpolates FE results into a global domain at nodal co-ordinates
fprintf(': done\n');

save('tmp.mat')
%}

close all; clear all; colordef white; clc;

load('tmp.mat')
%% CRACK ORIENTATION AND PLASTICITY CHECK
%finding plasticity regions
Pla_reg = isplastic(el,mat.yield);

%Checking if the crack is on the good axis
H1 = prePlot(mesh,gl,0,Pla_reg,el);
% [mesh,mat,el,gl] = Crack_align(mesh,mat,el,gl);
H1 = prePlot2(mesh,gl,0,Pla_reg,el);

close(H1);


%% CONTOUR DETERMINATION

fprintf('\nChoose a processing method : ');
fprintf('\n[1] One contour calculation');
fprintf('\n[2] Multiple contour calculation\n');
reply = input('Choice :');

%Printing screen for manual choice of J-Integral contour, and mask function

H1=prePlot2(mesh,gl,1,Pla_reg,el);

[xmask, ymask] = ginput(2);
rectangle('Position',[min(xmask(1),xmask(2)),min(ymask(1),ymask(2)),abs(xmask(2)-xmask(1)),abs(ymask(2)-ymask(1))],'FaceColor','k'); drawnow;
[xmask,ymask] = convCoord(xmask,ymask,mesh.winFE,mesh.UFE);

[xo,yo] = ginput(2);
rectangle('Position',[min(xo(1),xo(2)),min(yo(1),yo(2)),abs(xo(2)-xo(1)),abs(yo(2)-yo(1))],'EdgeColor','W'); drawnow;
[xo,yo] = convCoord(xo,yo,mesh.winFE,mesh.UFE);

[xi,yi] = ginput(2);
rectangle('Position',[min(xi(1),xi(2)),min(yi(1),yi(2)),abs(xi(2)-xi(1)),abs(yi(2)-yi(1))],'EdgeColor','W');drawnow;
[xi,yi] = convCoord(xi,yi,mesh.winFE,mesh.UFE);

Jint.nout = [max(yo) min(yo); min(xo) max(xo)];
Jint.nin  = [max(yi) min(yi); min(xi) max(xi)];
Jint.mask = [ymask(1) ymask(2);xmask(1) xmask(2)];

saveas(H1,['results/' num2str(scan_number) '_selection.fig'])

close(H1);

%% J-INTEGRAL CALCULATION

if reply == 1
    fprintf('\nJ-Integraling...');
    [Jint] = findJintelem(mat, mesh, el, Jint);  %finds elements within defined (Jint)ergral area, Jint.nout/nin
    [Jint] = getq(el, Jint, mesh);       %creates smooth virtual crack extension function q over Jint.nout/nin
    [Jint] = Jcalc(el, Jint, mat); %Solves for the Jintegral and equivelant fracture toughness K (LEFM)
    fprintf('done\n')
    fprintf(1,'Calculated J is %3.2f J/m^2\n', Jint.J);
    fprintf(1,'Equivelant K is %3.2f MPa sqrt(m)\n', Jint.K);
end

if reply ==2
    [Ctrs,Nb_ct] = CtrCalc(Jint);
    Results = zeros(Nb_ct,2);
    fprintf('\nJ-Integraling...\n');
    for i=1:Nb_ct
        fprintf('Contour %3i\n',i)
        Jint.nin(1,:)=Ctrs(i,1:2);
        Jint.nin(2,:)=Ctrs(i,3:4);
        Jint.nout(1,:)=Ctrs(i,5:6);
        Jint.nout(2,:)=Ctrs(i,7:8);
        Jint.mask = [ymask(1) ymask(2);xmask(1) xmask(2)];
        [Jint] = findJintelem(mat, mesh, el, Jint);  %finds elements within defined (Jint)ergral area, Jint.nout/nin
        [Jint] = getq(el,Jint, mesh);       %creates smooth virtual crack extension function q over Jint.nout/nin
        [Jint] = Jcalc(el,Jint, mat);
        
        Results(i,:)=[Jint.J Jint.K];
        
        if(i>Nb_ct)
            clear Jint;
        end
        %           plotDIC(mesh,el,mat,Jint);
    end
    fprintf(1,'Calculated J are :\n');
    fprintf(1,'%3.2f J/m^2\n', Results(:,1));
    fprintf(1,'Equivalant K are :\n');
    
    fprintf(1,'%3.2f MPa sqrt(m)\n', 1E-6.*Results(:,2));
    fprintf(1,'Average J is %3.2f J/m^2\n', mean(Results(:,1)));
    fprintf(1,'Average K is %3.2f MPa sqrt(m)\n', 1E-6.*mean(Results(:,2)));
    fprintf(1,'Std Dev for J is %3f\n', std(Results(:,1)));
    fprintf(1,'Std Dev for K is %3f\n', 1E-6.*std(Results(:,2)));
end


%% Plot
fprintf('\nPlotting results...');
%     plotDIC(mesh,el,mat,Jint);


figure
plot(1E-6* Results(:,2))
xlabel('Contour Number')
ylabel('K / MPa m^{1/2}')
saveas(gcf,['results/' num2str(scan_number) '_results.fig'])


plotFE(mesh,el,mat,Jint,gl);
saveas(gcf,['results/' num2str(scan_number) '_output.fig'])
fprintf('done\n')