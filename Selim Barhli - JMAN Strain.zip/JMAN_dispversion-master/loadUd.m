function [mesh] = loadUd(scan_number)

% Load nodal positions and diplacments
alldata=[];
%%


% load(fullfile(pwd, 'DIC', ['Portsmouth_DIC_[m]_' num2str(scan_number) '.mat']))
% scatter(alldata(:,1)*1E6,alldata(:,2)*1E6,4,alldata(:,4)*1E6)
% xlabel('x [\mum]'); ylabel('y [\mum]')
% colorbar

% Westergaard data
load(fullfile(pwd,'20MPa_[m]_[MPa]_DISP.mat'))
alldata = finaldata;
scatter(alldata(:,1)*1E6,alldata(:,2)*1E6,4,alldata(:,4)*1E6)
xlabel('x [\mum]'); ylabel('y [\mum]')
colorbar

%Portsmouth Data
%
% load('GeorginaTestData\SNG722_TR_Smoothed\GraphiteDataRotatedGridded_105.mat');
%}
% alldata = M60WS64SNR15real45JMAN;

%Westergaard data
%{
load('30MPa_[mm]_[MPa]_DISP')
alldata = finaldata;
%}

%StrainsFEBench data
%{
load('Test Data/DispsFEBench.mat')
%}

%%
%x flip
%{
alldata = alldata./1000;
alldata(:,1) = -alldata(:,1); % flip x
alldata(:,3) = -alldata(:,3); % flip ux
%}
% alldata(isnan(alldata)) = 0;
% 
dispsU_1 = alldata(:,1:2);
dispsd_1 = alldata(:,3:4);
% 
% % Intepolate on regular grid if necessary
% Nx = length(unique(dispsU_1(:,1))); Ny = length(unique(dispsU_1(:,2)));
% xrdXq=min(dispsU_1(:,1)):roundn((max(dispsU_1(:,1))-min(dispsU_1(:,1)))/Nx,-5):max(dispsU_1(:,1));
% xrdYq=min(dispsU_1(:,2)):roundn((max(dispsU_1(:,2))-min(dispsU_1(:,2)))/Ny,-5):max(dispsU_1(:,2));
% 
% [Xq, Yq] = meshgrid(xrdXq,xrdYq);
% 
% xrdUxq =griddata(dispsU_1(:,1),dispsU_1(:,2),dispsd_1(:,1),Xq,Yq);
% xrdUyq =griddata(dispsU_1(:,1),dispsU_1(:,2),dispsd_1(:,2),Xq,Yq);
% 
% % clear StrainU_1 Straind_1
% dispsU_1 = [Xq(:) Yq(:)];
% dispsd_1 = [xrdUxq(:) xrdUyq(:)];
% 
% 
tmp(1:2,:)=dispsU_1';
tmp(3:4,:)=dispsd_1';


%Guess the dimensions of the image
mesh.winDIC = GetSize(tmp(2,:));

% sort the dataset
tmp = sortrows(tmp',[1 2])';

mesh.UDIC =tmp(1:2,:);
mesh.dDIC =tmp(3:4,:);

mesh.winFE  = [2 2; mesh.winDIC(1)-1 mesh.winDIC(2)-1];
% mesh.winFE  = [1 1; mesh.winDIC(1) mesh.winDIC(2)];
