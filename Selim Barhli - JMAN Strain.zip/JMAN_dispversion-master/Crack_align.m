function [mesh,mat,el,gl] = Crack_align(mesh,mat,el,gl)

reply = input('Is the crack on the x axis? Y/N [Y]: ', 's');
if isempty(reply)
    reply = 'Y';
end
if(reply=='N')
    mesh.winDIC = fliplr(mesh.winDIC);
    mesh.winFE = fliplr(mesh.winFE);
    Tri(1:2,:) = flipud(mesh.UDIC);
    Tri(3:4,:) = flipud(mesh.dDIC);
    
    %     for ii=1:length(Tri)-1
    %         for i=1:length(Tri)-1
    %             if(Tri(2,i)>Tri(2,i+1))
    %                     buf=Tri(:,i);
    %                     Tri(:,i)=Tri(:,i+1);
    %                     Tri(:,i+1)=buf;
    %             end
    %         end
    %     end
%     
%     for j=1:mesh.winDIC(2)
%         index1 = (j-1)*mesh.winDIC(1)+1;
%         index2 = (j)*mesh.winDIC(1);
%         for ii=index1:index2
%             for i=index1:index2-1
%                 if(Tri(1,i)>Tri(1,i+1))
%                     buf=Tri(:,i);
%                     Tri(:,i)=Tri(:,i+1);
%                     Tri(:,i+1)=buf;
%                 end
%             end
%         end
%     end
    Tri = sortrows(Tri',[1 2])';
    mesh.UDIC = Tri(1:2,:);
    mesh.dDIC = Tri(3:4,:);
%     mesh.strainU = flipud(mesh.strainU);
    
    [el,mesh] = meshDIC(mat,mesh);
    [el] = FEanalysisStrains(el,mat,mesh);
    [gl] = makeglobal(el, mesh);
end