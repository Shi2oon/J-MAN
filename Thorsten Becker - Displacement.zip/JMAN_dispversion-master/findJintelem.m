function [Jint] = findJintelem(~, mesh, el, Jint)

nodes = reshape(1:length(mesh.UDIC),mesh.winDIC(2),mesh.winDIC(1));

Jint.nout(Jint.nout>max(mesh.winDIC)) = max(mesh.winDIC);

Jintnodes = zeros(size(nodes));
Jintnodes(min(Jint.nout(1,:)):max(Jint.nout(1,:)),min(Jint.nout(2,:)):max(Jint.nout(2,:)))=1;
Jintnodes((min(Jint.nin(1,:))+1):(max(Jint.nin(1,:))-1),(min(Jint.nin(2,:))+1):(max(Jint.nin(2,:))-1)) = 0;
Jintnodes(min(Jint.mask(1,:)):max(Jint.mask(1,:)),min(Jint.mask(2,:)):max(Jint.mask(2,:)))=0;

Jintnodes = Jintnodes.*nodes;
Jintnodes = unique(Jintnodes);
Jintnodes(Jintnodes==0)=[];

elnum =1;
for c = 1:length(el.n)
    if(sum(ismember(el.n(c,:),Jintnodes))==4)
        JDelem(elnum) = c;
        elnum = elnum+1;
    end
end

Jint.el = JDelem';
%% find nodes within (Jint)ergral integration area
% disp 'CHANGEMENT ICI'


% sizeFE = abs(mesh.winFE(1,:)-mesh.winFE(2,:))+1;
% % nodes = reshape(1:length(mesh.UDIC),mesh.winDIC(1),mesh.winDIC(2))';
% 
% % attention le tableu des nodes est rang� dans l'autre sens que le tableau
% % des �l�mets
% nodes = reshape(1:length(mesh.UFE),sizeFE(2),sizeFE(1));
% 
% Jintnodes = zeros(size(nodes));
% Jintnodes(min(Jint.nout(1,:)):max(Jint.nout(1,:)),min(Jint.nout(2,:)):max(Jint.nout(2,:)))=1;
% Jintnodes((min(Jint.nin(1,:))+1):(max(Jint.nin(1,:))-1),(min(Jint.nin(2,:))+1):(max(Jint.nin(2,:))-1)) = 0;
% %Don't consider value inside the mask
% Jintnodes(min(Jint.mask(1,:)):max(Jint.mask(1,:)),min(Jint.mask(2,:)):max(Jint.mask(2,:)))=0;
% 
% 
% 
% Jintnodes = Jintnodes.*nodes;
% % Jintnodes = reshape(Jintnodes',1,numel(Jintnodes));
% %% find elements within (Jint)ergral integration area
% 
% %         for c = mesh.winFE(1,1):1:mesh.winFE(2,1)-1
% %             for r = mesh.winFE(1,2):1:mesh.winFE(2,2)-1
% %                 elnum = elnum + 1;
% %                 nodenum = [c+(r)*mesh.winDIC(1) ...
% %                            c+1+(r)*mesh.winDIC(1), ...
% %                            c+1+(r-1)*mesh.winDIC(1), ...
% %                            c+(r-1)*mesh.winDIC(1)];
% %                 JDelem(elnum) = (sum(nodenum==Jintnodes(nodenum))==4)*elnum;
% %             end
% %         end
% Jintnodes = unique(Jintnodes);
% %remove element 0
% elnum =1;
% Jintnodes = Jintnodes(2:end);
% for c = 1:length(el.n)
%     if(sum(ismember(el.n(c,:),Jintnodes))==4)
%         JDelem(elnum) = c;
%         elnum = elnum+1;
%     end
% end
% 
% Jint.el = JDelem';

%remove elements with zero displacment and find FE element numbering
% JDelem = JDelem(mesh.DICtoFE);
% JintelDIC = (JDelem(JDelem~=0))';
% for elem = 1:length(JintelDIC)
%     JFelem(elem) =  find(mesh.DICtoFE==JintelDIC(elem));
% end
% Jint.el = JFelem';