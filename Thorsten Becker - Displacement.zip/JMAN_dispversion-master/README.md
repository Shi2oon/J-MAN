# JMAN_dispversion
Calculates J-integral from displacement field (DIC)
