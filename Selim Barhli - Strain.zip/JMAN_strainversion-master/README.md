# JMAN_strainversion
JMAN calculation from strain maps (EDXD / XRD)
