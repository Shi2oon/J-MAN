close all

minGrid = -4E-3; % [m]
gridStep = 0.1E-3; % [m]
maxGrid = 4E-3; % [m]

xvec = minGrid : gridStep : maxGrid; % [m]
yvec = minGrid : gridStep : maxGrid; % [m]

[x,y] = meshgrid(xvec,yvec); % [m]
StressIntensityFactor = 30; % [MPa m^0.5]
K_I = StressIntensityFactor * 1E6; % Stress intensity factor [Pa m^0.5]
E = 210E9; % Young's Modulus [Pa]
nu = 0.3; % poisson ratio
mu = E/(2.*(1+nu)); % Shear Modulus [Pa]
state = 'plane_strain';
switch state
    case 'plane_strain'
        kappa = 3 - (4 .* nu); % [/]
    case 'plane_stress'
        kappa = (3 - nu)./(1 + nu); % [/]
end
[theta,r] = cart2pol(x,y);
ux = (K_I./(2.*mu)).*sqrt(r/(2*pi)).*cos(theta/2).*(kappa - 1 + 2.*(sin(theta/2)).^2); % Anderson p99 A2.44a
uy = (K_I./(2.*mu)).*sqrt(r/(2*pi)).*sin(theta/2).*(kappa + 1 - 2.*(cos(theta/2)).^2); % Anderson p99 A2.44b
[dux_dx,dux_dy] = gradient(ux,gridStep);
[duy_dx,duy_dy] = gradient(uy,gridStep);
exx = dux_dx;
eyy = duy_dy;
exy = 0.5*(dux_dy + duy_dx);

% save disps data
finaldata = [x(:) y(:) ux(:) uy(:)]; % [m]
save([num2str(StressIntensityFactor) 'MPa_[m]_[MPa]_DISP.mat'],'finaldata')
finaldata = [x(:) y(:) ux(:) uy(:)].*1000; % [mm]
save([num2str(StressIntensityFactor) 'MPa_[mm]_[MPa]_DISP.mat'],'finaldata')


% save strain data
finaldata = [x(:) y(:) exx(:) eyy(:) exy(:)]; % [m]
save([num2str(StressIntensityFactor) 'MPa_[m]_[MPa].mat'],'finaldata')
finaldata = [x(:).*1000 y(:).*1000 exx(:) eyy(:) exy(:)]; % [mm]
save([num2str(StressIntensityFactor) 'MPa_[mm]_[MPa].mat'],'finaldata')

% figure
% quiver(x,y,ux,uy)

figure
% subplot(2,4,1)
% imagesc(xvec,yvec,x)
% colorbar
% colormap(jet)
% title('x')
% xlabel('x')
% ylabel('y')
% axis('image')
% set(gca,'YDir','normal')
% 
% subplot(2,4,2)
% imagesc(xvec,yvec,y)
% colorbar
% title('y')
% xlabel('x')
% ylabel('y')
% axis('image')
% set(gca,'YDir','normal')

subplot(2,4,1)
imagesc(xvec,yvec,r)
colorbar
title('r')
xlabel('x')
ylabel('y')
axis('image')
set(gca,'YDir','normal')

subplot(2,4,2)
imagesc(xvec,yvec,theta)
colorbar
title('theta')
xlabel('x')
ylabel('y')
axis('image')
set(gca,'YDir','normal')

subplot(2,4,3)
C = ux;
imagesc(xvec,yvec,C)
colorbar
title('ux')
xlabel('x')
ylabel('y')
axis('image')
set(gca,'YDir','normal')

subplot(2,4,4)
C = uy;
imagesc(xvec,yvec,C)
colorbar
title('uy')
xlabel('x')
ylabel('y')
axis('image')
set(gca,'YDir','normal')

subplot(2,4,5)
C = exx;
clim = [0 0.01];
imagesc(xvec,yvec,C,clim)
colorbar
title('exx')
xlabel('x')
ylabel('y')
axis('image')
set(gca,'YDir','normal')

subplot(2,4,6)
C = eyy;
clim = [0 0.01];
imagesc(xvec,yvec,C,clim)
colorbar
title('eyy')
xlabel('x')
ylabel('y')
axis('image')
set(gca,'YDir','normal')

subplot(2,4,7)
C = exy;
clim = [-0.01 0.01];
imagesc(xvec,yvec,C,clim)
colorbar
title('exy')
xlabel('x')
ylabel('y')
axis('image')
set(gca,'YDir','normal')


% figure
% mesh(x,y,uy)
% zlabel('uy')
% xlabel('x')
% ylabel('y')