clear; colordef white; clc; close all;

%% USER ENTERS INPUT MATERIAL PROPERTIES AND DATA PATHS
fprintf('\nLoading data...');
scan_ID = 66857;
scan_dir = 'C:\Users\Phllip\OneDrive - Nexus365\Documents\Other Experiments\Diamond Light Source\EE13579-1\EDXD\2b. Pyxe Analysis';
input_unit = 'mm';

mat.nu = 0.3;
mat.E  = 210E9; % [Pa]
mat.yield = 820E6; % [Pa]
mat.stressstate = 'plane_strain'; %set to'plane_strain' or 'plane_stress'

results_dir = 'C:\Users\Phllip\OneDrive - Nexus365\Documents\Other Experiments\Diamond Light Source\EE13579-1\EDXD\3. EDXD JMAN Analysis\results';

%% Run JMAN_strainversion
main