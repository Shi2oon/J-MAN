clear; clc;
close all

%% 
figure

scan_numbers = [66842,66844,66845,66846,66850,66852,66853,66854,66855,66856,66857];
ii = 0;
for scan_number = scan_numbers
    load(['RES_' num2str(scan_number)],'-mat','Results')
    ii = ii + 1;
    K{1,ii} = Results(:,2);
    K{2,ii} = scan_number;
    K{3,ii} = mean(Results(:,2));
    
    
    plot(Results(1:13,2),'DisplayName',num2str(scan_number))
    hold on
    
end

legend('show')