function [loc,weight] = gaussquad(~)

% w = 1/2;
loc=[0; 0];
weight=4;